CREATE OR REPLACE VIEW reporting_{} AS
    SELECT
          *
    FROM "{}"
    WHERE "latest_version"
