# Glue Crawler Initiation
This lambda initiates an existing Glue Crawler via a simple Python Lambda using a boto3
`start_crawler` call.
